import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-celebration',
  templateUrl: './celebration.component.html',
  styleUrls: ['./celebration.component.css']
})
export class CelebrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
