import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testimoinal',
  templateUrl: './testimoinal.component.html',
  styleUrls: ['./testimoinal.component.css']
})
export class TestimoinalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
